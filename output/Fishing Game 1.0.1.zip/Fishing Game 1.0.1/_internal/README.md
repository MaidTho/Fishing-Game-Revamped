<br>
<br>

---------------------------------------------------
<h1 align="center">PROJECT INTRODUCTION</h1>
<p align="center"> This project as the repo states, is a revamped version of the Fishing Game built in Python succeeding from a previous project. </p>
<br>
<br> 

---------------------------------------------------
<h1 align="center">PREREQUISITES</h1>

    • None Needed.

<br>
<br>

---------------------------------------------------
<h1 align="center">INSTALLATION</h1>

OPTION 1!

    • Go to output folder.
    • Download source code .Zip file.
    • Extract Folder.
    • Launch .exe file "Fishing Game".
    • Enjoy!

<br>
<br>

---------------------------------------------------
<h1 align="center">LATEST RELEASE NOTES</h1>
<p align="center">(https://github.com/MaidTho/Fishing-Game-Revamped/releases/tag/v3.0.0)

            - - - N E W F E A T U R E S - - - 

    • NEW!!! Updated GUI.
    • NEW!!! Shop GUI Updated.
    • NEW!!! Life / Hazard system.
    • NEW!!! Playable Demo.
    

</p>
<br>
<br>

---------------------------------------------------
<h1 align="center">FEATURES INCLUDED</h1>

<p align="center">


    • Cast Line once or however many times you wish!
    • Updated Graphical User Interface!
    • Login & Registration.
    • Leaderboard!
    • Shop to buy / sell fish and items.
    • Life / Hazard system.


</p>
<br>
<br>

---------------------------------------------------
<h1 align="center"> FUTURE FEATURES </h1>
<p align="center">
    
    • More Fish!
    • More Hazards!!
    • Mythical Creatures?

</p>
<br>
<br>









